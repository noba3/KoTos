# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import urllib,urllib2,re,xbmcplugin,xbmcgui,sys,xbmc,xbmcaddon,xbmcvfs
import os,base64,araclar,cozucu,time,urlresolver
# -*- coding: iso-8859-9 -*-

__settings__ = xbmcaddon.Addon(id='plugin.video.tekosman')
__language__ = __settings__.getLocalizedString
home = __settings__.getAddonInfo('path')
icon = xbmc.translatePath( os.path.join( home, 'icon.png' ) )
fanart = xbmc.translatePath( os.path.join( home, 'fanart.jpg' ) )
folders = xbmc.translatePath(os.path.join(home, 'resources', 'lib'))
sys.path.append(folders)


#!/usr/bin/python
# -*- coding: utf-8 -*-         #print ""+url
# Copyright (c) 2013
# Writer (c) 2013, xbmcTR Team by HappyFeets
# Turkiye, E-mail: androidmkersco@gmail.com

xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
kinoo='aHR0cDovL3hibWN0ci5jb20vYWNjZXMvQWxpc3RhcktJTk8v'

def CATEGORIES():
        import time
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=get_url(base64.b64decode(web))
        time.sleep(2)
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
        kino='aHR0cDovL3hibWN0ci5jb20vYWNjZXMvQWxpc3RhcktJTk8v'
        tek='aHR0cDovL3Rla29zbWFucG93ZXJ0di5saW1hLWNpdHkuZGUvdGVrb3NtYW5wb3dlcnR2LnhtbA=='
        urll='aHR0cDovL3hibWN0ci5jb20vYWNjZXMv'
        addDir('[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B] Kino [/B][/COLOR]',(base64.b64decode(kino)),4,'http://kisalt.com/8l9')
        addDir('[COLOR blue][B]>>[/B][/COLOR] [COLOR orange][B] Karma iptv[/B][/COLOR]',(base64.b64decode(tek)),1,'http://kisalt.com/karma')
        link=get_url(base64.b64decode(urll))
        match=re.compile('<li><a href="(.*?)"> .*?</a></li>\n<li><a href="(.*?).xml"> .*?</a></li>').findall(link)
        for t,url in match:
                t=(base64.b64decode(urll))+t.encode('utf-8', 'ignore')
                name=url
                url=(base64.b64decode(urll))+url.encode('utf-8', 'ignore')+'.xml'
                addDir('[COLOR blue][B]>>  [/COLOR][COLOR lightgreen]'+ name+'[/B][/COLOR]',url,3,t)

def icerik(url):
        import time
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=get_url(base64.b64decode(web))
        time.sleep(2)
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
        link=get_url(url)
        match=re.compile('<name><!\[CDATA\[(.*?)\]\]></name>\n  <thumbnail><!\[CDATA\[(.*?)\]\]></thumbnail>\n  <link><!\[CDATA\[(.*?)\]\]></link>\n').findall(link)
        for name,t,url in match:
                addDir('[COLOR lightblue]>> [/COLOR][COLOR lightgreen]'+ name+'[/COLOR]',url,2,t)
        match1=re.compile('<title>(.*?)</title>\n  <thumbnail>(.*?)</thumbnail>\n  <link>(.*?)</link>\n').findall(link)
        for name,t,url in match1:
                addDir('[COLOR lightblue]>> [/COLOR][COLOR lightgreen]'+ name+'[/COLOR]',url,2,t)
def tek(url):
        import time
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=get_url(base64.b64decode(web))
        time.sleep(2)
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
        link=get_url(url)
        link=link.replace('&amp;','&')
        match=re.compile('<title>(.*?)</title>\n<link>(.*?)</link>\n<thumbnail>(.*?)</thumbnail>').findall(link)
        for name,url,t in match:
                addDir('[COLOR lightblue]>> [/COLOR][COLOR lightgreen]'+ name+'[/COLOR]',url,2,t)

def iplayer(name,url):
        import time
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=get_url(base64.b64decode(web))
        time.sleep(2)
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
        playList.clear()
        addLink(name,url,'')
        listitem = xbmcgui.ListItem(name)
        playList.add(url, listitem)
        xbmcPlayer.play(playList)

def kino(url):
        import time
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=get_url(base64.b64decode(web))
        time.sleep(2)
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
        link=get_url(url)
        match=re.compile('<li><a href="(.*?)"> .*?</a></li>\n<li><a href="(.*?).xml"> .*?</a></li>').findall(link)
        for t,url in match:
                t=(base64.b64decode(kinoo))+t.encode('utf-8', 'ignore')
                name=url
                url=(base64.b64decode(kinoo))+url.encode('utf-8', 'ignore')+'.xml'
                addDir('[COLOR lightblue]>>  [/COLOR][COLOR lightgreen]'+ name+'[/COLOR]',url,5,t)

def kinoicerik(url):
        import time
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=get_url(base64.b64decode(web))
        time.sleep(2)
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
        link=get_url(url)
        you=re.compile('<name><!\[CDATA\[(.*?)\]\]></name>\n  <thumbnail><!\[CDATA\[(.*?)\]\]></thumbnail>\n  <link><!\[CDATA\[(.*?)\]\]></link>').findall(link)
        for name,t,url in you:
                addDir('[COLOR lightblue]>>  [/COLOR][COLOR lightgreen]'+ name+'[/COLOR]',url,6,t)
        
def UrlResolver_Player(name,url):
        import time
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=get_url(base64.b64decode(web))
        time.sleep(2)
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
        UrlResolverPlayer = url
        playList.clear()
        media = urlresolver.HostedMediaFile(UrlResolverPlayer)
        source = media
        if source:
                url = source.resolve()
                araclar.addLink(name,url,'')
                araclar.playlist_yap(playList,name,url)
                xbmcPlayer.play(playList)

#############################################
def get_url(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        return link

def addLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok


def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
              
params=get_params()
url=None
name=None
mode=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)

if mode==None or url==None or len(url)<1:
        CATEGORIES()

elif mode==1:
        tek(url)

elif mode==2:
        iplayer(name,url)

elif mode==3:
        icerik(url)

elif mode==4:
        kino(url)

elif mode==5:
        kinoicerik(url)        

elif mode==6:
        UrlResolver_Player(name,url)
        
xbmcplugin.endOfDirectory(int(sys.argv[1]))
